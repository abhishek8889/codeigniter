<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// Method: POST, PUT, GET etc
// Data: array("param" => "value") ==> index.php?param=value

class Apicall extends CI_Controller {

    public function __construct()
    {
        $this->CI =& get_instance();
    }
    public function mkRequest($method, $url, $data = false)
    {
        $curl = curl_init();

        switch ($method)
        {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);

                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_PUT, 1);
                break;
            default:
                if ($data)
                    $url = sprintf("%s?%s", $url, http_build_query($data));
        }

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        $result = curl_exec($curl);

        curl_close($curl);

        return $result;
    }
}